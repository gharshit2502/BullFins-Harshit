import pandas as pd
# Load the dataset
file_path = r"C:\Users\admin\Downloads\finothon\finothon\finothon\finothon\data\SMS-Data.csv"
sms_data = pd.read_csv(file_path)

# Step 1: Remove Duplicates
# Remove rows that are completely identical
sms_data.drop_duplicates(inplace=True)#

# Step 2: Remove Empty or NaN Values
# Drop rows where any critical columns are NaN (e.g., 'id', 'text', 'updateAt')
sms_data.dropna(subset=['id', 'text', 'updateAt'], inplace=True)

# Alternatively, drop rows with any NaN values in the entire dataset
# sms_data.dropna(inplace=True)

# Step 3: Filter Out Spam or Irrelevant Data
#spam_keywords = ["free", "win", "congratulations", "prize", "offer", "click here"]
spam_keywords = [
    "free", "win", "prize", "offer", "limited time", "exclusive", "claim now",
    "urgent", "reward", "gift card", "chance to win", "hurry", "buy now", 
    "shopping", "special offer", "limited offer", "click here","account blocked", 
    "security alert", "login", "update your details", "confirm your account", "suspicious activity", 
    "fake", "password reset", "email update", "subscription", "get started", "new product", 
    "order now", "opportunity", "quick ", "easy money", 
    "rich quick",  "unsecured loan", "investment plan", "work from home", "easy job", 
    "part-time job", "job offer", "hire now", "freelance opportunity", "casino", 
    "gambling", "lottery", "investment scheme", "scam","recharge now","is your Zomato verification code","fraudsters"," Daily Data quota",
    "Buy1Get1","offers","offer","WhatsApp"," Facebook","Uber code"," Mitra verification","available to take calls","quota exhausted"," missed calls","greetings","http",
    "à",
]

# Filter SMS messages that contain any of the spam keywords
sms_data = sms_data[~sms_data['text'].str.contains('|'.join(spam_keywords), case=False, na=False)]


sms_data = sms_data[~sms_data['text'].str.contains('|'.join(spam_keywords), case=False, na=False)]

# Step 4: Remove Redundant Columns
# Drop unnecessary columns that are not needed for analysis
duplicate_rows = sms_data[sms_data.duplicated()]
missing_values = sms_data.isna().sum()
sms_data.drop(columns=['duplicate_rows','missing_values'], inplace=True, errors='ignore')

# Step 5: Reset Index
# After removing rows, reset the DataFrame index to keep it consecutive
sms_data.reset_index(drop=True, inplace=True)

# Step 6: Convert `updateAt` to datetime and Extract Components
# Convert the 'updateAt' column to datetime format
sms_data['updateAt'] = pd.to_datetime(sms_data['updateAt'], errors='coerce')

# Extract components from 'updateAt'
sms_data['date'] = sms_data['updateAt'].dt.date  # Extract the date part
sms_data['time'] = sms_data['updateAt'].dt.time  # Extract the time part
sms_data['month_year'] = sms_data['updateAt'].dt.to_period('M')  # Extract month and year
sms_data['year'] = sms_data['updateAt'].dt.year  # Extract the year
sms_data['month'] = sms_data['updateAt'].dt.month  # Extract the month
sms_data['day'] = sms_data['updateAt'].dt.day  # Extract the day
sms_data['weekday'] = sms_data['updateAt'].dt.day_name()  # Extract the weekday name (e.g., Monday, Tuesday)

# If you want the weekday in numeric form (0 for Monday, 1 for Tuesday, etc.):
sms_data['weekday_num'] = sms_data['updateAt'].dt.weekday

# Step 7: Save the cleaned data
sms_data.to_csv('cleaned_sms_data.csv', index=False)

print("Data cleaning and preprocessing completed. Cleaned data saved as 'cleaned_sms_data.csv'.")
