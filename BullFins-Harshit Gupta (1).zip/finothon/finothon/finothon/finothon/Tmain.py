#finotothon
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
# Define output directory
output_dir = r"C:\Users\admin\Downloads\finothon\finothon\finothon\finothon\outputs\visualizations"
file_path = r"C:\Users\admin\Downloads\finothon\finothon\cleaned_sms_data.csv"

os.makedirs(output_dir, exist_ok=True)

# Load the dataset7869
#file_path = 'data/SMS-Data.csv'
sms_data = pd.read_csv(file_path)

# Step 1: Data Cleaning
# Drop rows with missing values in critical columns
sms_data.dropna(subset=['phoneNumber','id', 'text', 'date'], inplace=True)

# Convert `date` column to datetime format
sms_data['date'] = pd.to_datetime(sms_data['date'], errors='coerce')

# Drop rows with invalid dates
sms_data.dropna(subset=['date'], inplace=True)

# Reset index after cleaning
sms_data.reset_index(drop=True, inplace=True)

# Step 2: Text Processing
# Define keywords to categorize financial transactions
categories = {
    'expenses': ["debited", "spent", "purchase", "paid","UPI"],
    'credit': ['credit','credit',"recived", "credited", "received", "deposit", "transferred", 
    "added", "credited to your account", "funds received", 
    "amount received", "credited successfully", 
    "payment received", "salary credited", "income received", 
    "cash deposit", "loan disbursed", "bonus credited", 
    "refund processed", "refund credited", "interest credited", "dividend credited", "cashback credited" ],
    'loan': ["loan", "emi", "overdue"],
    'share_market': ["stock", "share", "nifty", "sensex"],
    'fd': ["fixed deposit", "fd maturity", "interest credited"],
    'investment': ["mutual fund", "sip", "investment", "equity","insurance","real estate"],
    'subscription': ["subscription", "recurring payment", "renewal"]
}

def categorize_sms(text):
    for category, keywords in categories.items():
        if any(keyword in text.lower() for keyword in keywords):
            return category
    return 'others'

# Apply categorization to the `text` column
sms_data['category'] = sms_data['text'].apply(categorize_sms)

# Extract numerical amounts from SMS body
def extract_amount(text):
    import re
    # Extract potential numbers using regex
    amounts = re.findall(r'\b\d+(?:,\d{3})*(?:\.\d+)?\b', text)
    # Convert to float after removing commas
    amounts = [float(amount.replace(',', '')) for amount in amounts]
    return max(amounts, default=0)

sms_data['amount'] = sms_data['text'].apply(extract_amount)

# Step 3: Aggregating Data
# Extract date-related insights
sms_data['year'] = sms_data['date'].dt.year
sms_data['month'] = sms_data['date'].dt.month
sms_data['day'] = sms_data['date'].dt.day

# Count SMS by category
category_counts = sms_data['category'].value_counts()

# Count SMS by user and category
user_data = sms_data.groupby(['phoneNumber', 'category']).size().unstack(fill_value=0)

# Loan analysis
loan_data = sms_data[sms_data['category'] == 'loan']
loan_summary = loan_data.groupby('phoneNumber')['amount'].sum()





expenditure_data = sms_data[sms_data['category'] == 'expenses']
expenditure_summary = expenditure_data.groupby('phoneNumber')['amount'].sum()

# Expenditure type classification
threshold = 1000000000000

# Filter expenditure summary to include only users with expenditure greater than the threshold
expenditure_summary = expenditure_summary[expenditure_summary > threshold]


# Subscription analysis
subscription_data = sms_data[sms_data['category'] == 'subscription']
subscription_summary = subscription_data.groupby('phoneNumber')['amount'].sum()

# Step 4: Visualization
# Bar plot for SMS categories
plt.figure(figsize=(10, 6))
sns.barplot(x=category_counts.index, y=category_counts.values, palette='viridis')
plt.title('Distribution of SMS by Category', fontsize=16)
plt.xlabel('Category', fontsize=14)
plt.ylabel('Count', fontsize=14)
plt.xticks(rotation=90)
plt.savefig(os.path.join(output_dir, 'sms_category_distribution.png'))
plt.close()

# Loan analysis: Bar chart of total loan amounts per user
plt.figure(figsize=(12, 6))
loan_summary.sort_values(ascending=False).plot(kind='bar', color='orange')
loan_summary = loan_summary[loan_summary.notnull()].sort_values(ascending=False)
plt.title('Total Loan Amounts by User', fontsize=16)
plt.xlabel('User ID', fontsize=14)
plt.ylabel('Total Loan Amount', fontsize=14)
plt.xticks(rotation=90)
plt.savefig(os.path.join(output_dir, 'loan_summary.png'))
plt.close()
# Filter out null values and sort
loan_summary = loan_summary[loan_summary.notnull()].sort_values(ascending=False)

# Prepare data for scatter chart
x_values = range(len(loan_summary))  # X-axis values (indices of users)
y_values = loan_summary.values       # Y-axis values (loan amounts)
user_labels = loan_summary.index     # Labels for each user

plt.figure(figsize=(12, 6))

# Create scatter chart
plt.scatter(x_values, y_values, color='black', alpha=0.7, edgecolor='k')

# Add labels and title
plt.title('Total Loan Amounts by User', fontsize=16)
plt.xlabel('User ID', fontsize=14)
plt.ylabel('Total Loan Amount', fontsize=14)

# Add user labels to x-axis
plt.xticks(ticks=x_values, labels=user_labels, rotation=90)

# Save the scatter chart
plt.tight_layout()
plt.savefig(os.path.join(output_dir, 'loan_summary_scatter.png'))
plt.close()

# Expenditure analysis: Pie chart of expenditure distribution
plt.figure(figsize=(10, 10))
#expenditure_summary.plot(kind='pie', autopct='%1.1f%%', startangle=140, colors=sns.color_palette('pastel'))
expenditure_summary.plot(kind='pie', autopct='%1.1f%%', startangle=140, colors=sns.color_palette('pastel'), figsize=(8, 8))
plt.title('Expenditure Distribution by User', fontsize=16)
plt.ylabel('expense')
plt.savefig(os.path.join(output_dir, 'expenditure_distribution.png'))
plt.close()

# Prepare data for the scatter chart
x_values = range(len(expenditure_summary))  # X-axis values (indices of users)
y_values = expenditure_summary.values       # Y-axis values (expenditure amounts)
user_labels = expenditure_summary.index     # Labels for each user

plt.figure(figsize=(10, 10))

# Create scatter chart
plt.scatter(x_values, y_values, color='purple', alpha=0.7, edgecolor='k')

# Add labels and title
plt.title('Expenditure Distribution by User', fontsize=16)
plt.xlabel('Users', fontsize=14)
plt.ylabel('Expenditure Amount', fontsize=14)

# Add user labels for clarity
plt.xticks(ticks=x_values, labels=user_labels, rotation=90)

# Save the scatter chart
plt.tight_layout()
plt.savefig(os.path.join(output_dir, 'expenditure_distribution_scatter.png'))
plt.close()


# Subscription analysis: Bar chart of recurring payments
plt.figure(figsize=(12, 6))
subscription_summary.sort_values(ascending=False).plot(kind='bar', color='blue', label='order = Netflix')
plt.title('Recurring Payments by User', fontsize=16)
plt.xlabel('User ID', fontsize=14)
plt.ylabel('Recurring Payment Amount', fontsize=14)
plt.xticks(rotation=90)
plt.legend(loc='center left', bbox_to_anchor=(0.5, 0.8))  # Place the legend on the right-hand side
plt.savefig(os.path.join(output_dir, 'subscription_summary.png'))
plt.close()


# Heatmap of user activity
plt.figure(figsize=(12, 8))
sns.heatmap(user_data, cmap='YlGnBu', annot=True, fmt='d')
plt.title('User Activity by SMS Category', fontsize=16)
plt.xlabel('Category', fontsize=14)
plt.ylabel('User ID', fontsize=14)
plt.savefig(os.path.join(output_dir, 'user_activity_heatmap.png'))
plt.close()


#message trend over time 

# Aggregate messages by month and category
sms_data['month_year'] = sms_data['date'].dt.to_period('M')
message_trends = sms_data.groupby(['month_year', 'category'])['id'].count().unstack(fill_value=0)

# Plot message trends over time

# plt.figure(figsize=(12, 6))
# message_trends.plot(ax=plt.gca(), marker='o')
# plt.title('Message Trends Over Time by Category', fontsize=16)
# plt.xlabel('Month-Year', fontsize=14)
# plt.ylabel('Number of Messages', fontsize=14)
# plt.xticks(rotation=90)
# plt.legend(title='Category')
# plt.legend(title='Category')


# Ensure the index of message_trends is converted to a string or datetime for plotting
# Convert the index to string for proper formatting
message_trends.index = message_trends.index.astype(str)

# Graph 1: Using message_trends.plot() - Line Plot
plt.figure(figsize=(12, 6))
message_trends.plot(ax=plt.gca())  # Remove marker='o' for line plot
plt.title('Message Trends Over Time by Category', fontsize=16)
plt.xlabel('Month-Year', fontsize=14)
plt.ylabel('Number of Messages', fontsize=14)
plt.xticks(rotation=90)
plt.legend(title='Category', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.savefig(os.path.join(output_dir, 'message_trends_over_time.png'))
plt.close()

# Graph 2: Customized Line Graph with Annotation
plt.figure(figsize=(12, 6))
for category in message_trends.columns:
    plt.plot(message_trends.index, message_trends[category], label=category)  # Line plot without markers
plt.title('Message Trends Over Time by Category (Customized)', fontsize=16)
plt.xlabel('Month-Year', fontsize=14)
plt.ylabel('Number of Messages', fontsize=14)
plt.xticks(rotation=90)
plt.legend(title='Category', bbox_to_anchor=(1.05, 1), loc='upper left')  # Legend placed to the right
plt.grid(axis='y', linestyle='--', alpha=0.7)  # Optional grid for better readability

# Add custom text annotation to the customized graph
plt.text(
    x=0.5, y=0.95,  # Coordinates in the axes fraction (relative position on the plot)
    s="Month = May, Date = 01-15",
    fontsize=12,
    transform=plt.gca().transAxes,  # Ensure coordinates are relative to the axes
    ha='center', va='center',
    bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=0.3')  # Optional styling for the text box
)

plt.tight_layout()  # Ensures the layout fits well
plt.savefig(os.path.join(output_dir, 'message_trends_over_time_line.png'))
plt.close()



#user wise data split
# User-wise spending by category
user_spending = sms_data.groupby(['phoneNumber', 'category'])['amount'].sum().unstack(fill_value=0)

# Bar chart: Total spending per user
plt.figure(figsize=(12, 6))
user_spending.sum(axis=1).sort_values(ascending=False).plot(kind='bar', color='teal')
plt.title('Total Spending Per User', fontsize=16)
plt.xlabel('User ID', fontsize=14)
plt.ylabel('Total Spending', fontsize=14)
plt.xticks(rotation=90)
plt.savefig(os.path.join(output_dir, 'total_spending_per_user.png'))
plt.close()
# Calculate total spending per user
total_spending_per_user = user_spending.sum(axis=1).sort_values(ascending=False)

# Convert to scatter chart
plt.figure(figsize=(12, 6))
plt.scatter(
    total_spending_per_user.index,  # x-axis: User IDs
    total_spending_per_user.values,  # y-axis: Total spending
    color='teal', 
    marker='+', 
    s=100  # Size of scatter points
)

# Add title and labels
plt.title('Total Spending Per User', fontsize=16)
plt.xlabel('User ID', fontsize=14)
plt.ylabel('Total Spending', fontsize=14)
plt.xticks(rotation=90)

# Save the scatter plot
plt.tight_layout()
plt.savefig(os.path.join(output_dir, 'total_spending_per_user_scatter.png'))
plt.close()



# Heatmap: Spending distribution across categories
plt.figure(figsize=(12, 8))
sns.heatmap(user_spending, cmap='coolwarm', fmt=".2f")
plt.title('Spending Distribution by User and Category', fontsize=16)
plt.xlabel('Category', fontsize=14)
plt.ylabel('User ID', fontsize=14)
plt.savefig(os.path.join(output_dir, 'spending_distribution_heatmap.png'))
plt.close()

# User-wise spending trends over time
user_trends = sms_data.groupby(['phoneNumber', 'month_year'])['amount'].sum().unstack(fill_value=0)

# Plot individual user's spending trends
plt.figure(figsize=(12, 8))
user_trends.T.plot(ax=plt.gca(), marker='o', alpha=0.7)
plt.title('User Spending Trends Over Time', fontsize=16)
plt.xlabel('Month-Year', fontsize=14)
plt.ylabel('Total Spending', fontsize=14)
plt.legend(title='User ID', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.xticks(rotation=90)
plt.savefig(os.path.join(output_dir, 'user_spending_trends.png'))
plt.close()


#credietd data graphs
credit_data = sms_data[sms_data['category'] == 'credit']
credit_summary = credit_data.groupby('phoneNumber')['amount'].sum()
print(credit_summary.head())

plt.figure(figsize=(18, 6))

# Convert the series to a list for scatter plot
phone_numbers = credit_summary.index.tolist()
amounts = credit_summary.values.tolist()

# Scatter plot with "+" markers
plt.scatter(phone_numbers, amounts, color='green', marker='+')

plt.title('Total Credited Amount by Phone Number', fontsize=16)
plt.xlabel('Phone Number', fontsize=14)
plt.ylabel('Total Credited Amount', fontsize=14)
#plt.xticks(rotation=90)
plt.xticks(ticks=None, labels=None, rotation=90)


plt.tight_layout()
plt.savefig(os.path.join(output_dir, 'credit_amount_scatter.png'))
plt.close()
# Step 5: Export insights per user
user_data.to_csv(os.path.join(output_dir, 'user_insights.csv'))

# Export cleaned data
#sms_data.to_csv('cleaned_sms_data.csv', index=False)

print("Data cleaning, processing, and visualization completed. Visualizations and user insights saved to the specified directory. Cleaned data saved as 'cleaned_sms_data.csv'.")
