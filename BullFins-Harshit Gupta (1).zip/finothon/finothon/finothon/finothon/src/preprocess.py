

# import pandas as pd
# import os

# import pandas as pd

# def preprocess_data(input_path, output_path):
#     try:
#         # Load the dataset
#         data = pd.read_csv(input_path)
        
#         # Check and rename columns if necessary
#         if 'body' in data.columns and 'text' not in data.columns:
#             data.rename(columns={"body": "text"}, inplace=True)
        
#         # Ensure the required columns exist
#         required_columns = ['text', 'updateAt']
#         for col in required_columns:
#             if col not in data.columns:
#                 raise ValueError(f"Column '{col}' is missing from the dataset.")
        
#         # Clean the data
#         data['text'] = data['text'].astype(str)  # Ensure 'text' is string
#         data['updateAt'] = pd.to_datetime(data['updateAt'], errors='coerce')  # Convert 'updateAt' to datetime
#         data = data.dropna(subset=['text', 'updateAt'])  # Drop rows with missing values in 'text' or 'updateAt'

#         # Save the processed data
#         data.to_csv(output_path, index=False)
#         return data

#     except Exception as e:
#         raise RuntimeError(f"Error during preprocessing: {e}")

 


# def extract_financial_details(text):
#     # Extract amount using regex
#     amount_pattern = r"Rs\.?[\s]*[0-9,]+(?:\.\d{1,2})?"
#     amounts = re.findall(amount_pattern, text)
    
#     # Clean up amounts (remove 'Rs.' and commas)
#     amounts = [float(a.replace("Rs.", "").replace(",", "").strip()) for a in amounts]
    
#     # Extract company/merchant name (example logic, adjust as per your data)
#     company_pattern = r"via ([A-Za-z0-9\s]+)"
#     companies = re.findall(company_pattern, text)
    
#     return {"amounts": amounts, "companies": companies}

# def preprocess_financial_data(data):
#     # Filter financial messages
#     financial_data = data[data['category'] == 'Financial'].copy()
    
#     # Extract details
#     financial_data['details'] = financial_data['text'].apply(extract_financial_details)
    
#     # Explode amounts and companies for better analysis
#     financial_data = financial_data.explode('details')
#     financial_data['amount'] = financial_data['details'].apply(lambda x: x['amounts'] if isinstance(x, dict) else [])
#     financial_data['company'] = financial_data['details'].apply(lambda x: x['companies'][0] if isinstance(x, dict) and x['companies'] else None)
    
#     return financial_data
# import pandas as pd



# Clean the data by dropping rows with missing critical values and processing relevant fields

# Drop rows where critical columns are null
cleaned_data = data.dropna(subset=['sms_id', 'body', 'creator', 'date']).copy()

# Convert the 'date' column to datetime format
cleaned_data['date'] = pd.to_datetime(cleaned_data['date'], errors='coerce')

# Drop rows with invalid datetime entries
cleaned_data = cleaned_data.dropna(subset=['date'])

# Extract message category (e.g., Financial, Promotional) from 'body' using basic rules (this can be expanded)
def categorize_message(message):
    if any(keyword in message.lower() for keyword in ['debited', 'credited', 'transaction', 'payment']):
        return 'Financial'
    elif any(keyword in message.lower() for keyword in ['offer', 'discount', 'sale', 'deal']):
        return 'Promotional'
    else:
        return 'Others'

cleaned_data['category'] = cleaned_data['body'].apply(categorize_message)

# Save the cleaned and categorized data for further use
cleaned_file_path = '/mnt/data/cleaned_SMS_Data.csv'
cleaned_data.to_csv(cleaned_file_path, index=False)

# Provide a brief summary of the cleaned data
summary = cleaned_data['category'].value_counts()
cleaned_file_path, cleaned_data.head(), summary
