# # main.py

# import pandas as pd
# import os
# import logging
# from preprocess import preprocess_data
# from analysis import categorize_messages, extract_company_names, analyze_data
# from visualization import plot_category_distribution, plot_message_trends

# import matplotlib

# # Set up logging
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger()

# def main():
#     try:
#         # Set up input/output paths
#         input_data_path = "data/raw_data.csv"
#         processed_data_path = "data/processed_data.csv"
#         output_visualizations_path = "outputs/visualizations"
        
#         # Check if input file exists
#         if not os.path.exists(input_data_path):
#             logger.error(f"Input file {input_data_path} not found.")
#             return
        
#         # Step 1: Load data
#         logger.info("Loading data...")
#         df = pd.read_csv(input_data_path)
#         logger.info(f"Loaded {len(df)} rows of data.")

#         # Step 2: Preprocess data
#         logger.info("Preprocessing data...")
#         df_cleaned = preprocess_data(df)
#         df_cleaned.to_csv(processed_data_path, index=False)
#         logger.info(f"Processed data saved to {processed_data_path}.")

#         # Step 3: Analyze data
#         logger.info("Analyzing data...")
#         analysis_results = analyze_data(df_cleaned)

#         # Step 4: Visualize data
#         logger.info("Generating visualizations...")

#         # Call the correct visualization functions
#         plot_category_distribution(df_cleaned, os.path.join(output_visualizations_path, "category_distribution.png"))
#         plot_message_trends(df_cleaned, os.path.join(output_visualizations_path, "message_trends.png"))

#         logger.info("Process completed successfully.")

#     except Exception as e:
#         logger.error(f"An error occurred: {e}")

# if __name__ == "__main__":
#     main()
####################################################################################################################
import os
import logging
from src.preprocess import preprocess_data
from src.analysis import categorize_messages, extract_sender_info
from src.visualization import plot_category_distribution, plot_message_trends

# Configure logging
logging.basicConfig(level=logging.INFO)

def main():
    # Define paths
    input_data_path = "data/SMS-Data.csv"
    processed_data_path = "data/Processed_SMS_Data.csv"
    visualization_path = "outputs/visualizations"

    # Step 1: Preprocess the data
    logging.info("Preprocessing data...")
    cleaned_data = preprocess_data(input_data_path, processed_data_path)
    logging.info(f"Processed data saved to {processed_data_path}.")

    # Step 2: Analyze the data
    logging.info("Analyzing data...")
    categorized_data = categorize_messages(cleaned_data)
    sender_info = extract_sender_info(categorized_data)

    # Step 3: Visualize the data
    logging.info("Generating visualizations...")
    plot_category_distribution(categorized_data, visualization_path)
    plot_message_trends(categorized_data, visualization_path)

    logging.info("Process completed successfully.")

if __name__ == "__main__":
    main()
