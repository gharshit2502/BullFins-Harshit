import pandas as pd

# Load the CSV file
file_path = "SMS-Data.csv"
data = pd.read_csv(file_path)

# Display basic info and preview
print(data.info())   # To understand columns and data types
print(data.head())   # First few rows for context

# Drop duplicates and handle missing values
data.drop_duplicates(inplace=True)
data.dropna(subset=['body', 'address', 'creator'], inplace=True)

# Preview cleaned data
print(data.head())

def categorize_message(body):
    if re.search(r'payment|transaction|balance|amount|due', body.lower()):
        return 'Financial'
    elif re.search(r'offer|discount|promo', body.lower()):
        return 'Promotional'
    else:
        return 'Other'

data['category'] = data['body'].apply(categorize_message)
print(data['category'].value_counts())


# Extract company names
data['company'] = data['address'].str.extract(r'(\b[A-Za-z]+\b)')
print(data['company'].value_counts())




import matplotlib.pyplot as plt

data['date'] = pd.to_datetime(data['date'])
financial_data = data[data['category'] == 'Financial']
financial_data.set_index('date')['id'].resample('M').count().plot()
plt.title("Monthly Financial Messages Trend")
plt.show()


import seaborn as sns

sns.countplot(data=data, x='category')
plt.title("Message Category Distribution")
plt.show()


data.to_csv("processed_data.csv", index=False)
