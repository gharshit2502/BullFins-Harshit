
def categorize_messages(data):
    # Categorize messages based on keywords
    def categorize(text):
        if any(word in text.lower() for word in ['rs.', 'amount', 'transaction', 'payment']):
            return 'Financial'
        elif any(word in text.lower() for word in ['offer', 'sale', 'discount', 'win']):
            return 'Promotional'
        return 'Other'

    data['category'] = data['text'].apply(categorize)
    return data

def extract_sender_info(data):
    # Extract unique senders and their message counts
    sender_summary = data['senderAddress'].value_counts().reset_index()
    sender_summary.columns = ['Sender', 'Message Count']
    return sender_summary
import pandas as pd

def analyze_financial_data(data):
    # Total spending by month
    data['month'] = data['updateAt'].dt.to_period('M')
    monthly_spending = data.groupby('month')['amount'].sum()
    
    # Top companies by transaction count
    top_companies = data['company'].value_counts().head(5)
    
    # Return results
    return {
        "monthly_spending": monthly_spending,
        "top_companies": top_companies
    }
def categorize_messages(data):
    def categorize(text):
        if re.search(r'(Rs\.|INR)', text, re.IGNORECASE):
            return 'Financial'
        return 'Other'

    data['category'] = data['text'].apply(categorize)
    return data

def extract_sender_info(data):
    return data['senderAddress'].value_counts()

def extract_financial_insights(data):
    financial_data = data[data['category'] == 'Financial']

    financial_data['amount'] = financial_data['text'].str.extract(r'(\d+[,.]?\d*)').astype(float)
    financial_data['month'] = financial_data['updateAt'].dt.to_period('M')

    return financial_data[['updateAt', 'senderAddress', 'text', 'amount', 'month']]

