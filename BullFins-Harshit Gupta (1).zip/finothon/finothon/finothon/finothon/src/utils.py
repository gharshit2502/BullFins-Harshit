import re
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

stop_words = set(stopwords.words('english'))

def clean_text(text):
    text = re.sub(r'[^A-Za-z0-9 ]+', '', text)  # Remove special characters
    tokens = word_tokenize(text.lower())
    return [word for word in tokens if word not in stop_words]
