import matplotlib.pyplot as plt
import seaborn as sns
import os

def plot_category_distribution(data, output_path):
    sns.countplot(data=data, x='category')
    plt.title("Message Category Distribution")
    plt.xlabel("Category")
    plt.ylabel("Count")
    os.makedirs(output_path, exist_ok=True)
    plt.savefig(os.path.join(output_path, "category_distribution.png"))
    plt.close()

def plot_message_trends(data, output_path):
    # Monthly trends for financial messages
    data['month'] = data['updateAt'].dt.to_period('M')
    trend_data = data[data['category'] == 'Financial'].groupby('month').size()
    trend_data.plot(kind='line', title="Monthly Financial Message Trends", ylabel="Count")
    os.makedirs(output_path, exist_ok=True)
    plt.savefig(os.path.join(output_path, "financial_trends.png"))
    plt.close()

def plot_financial_trends(monthly_spending, output_path):
    monthly_spending.plot(kind='bar', title="Monthly Spending Trends", ylabel="Amount (Rs)")
    os.makedirs(output_path, exist_ok=True)
    plt.savefig(os.path.join(output_path, "financial_trends.png"))
    plt.close()

def plot_top_companies(top_companies, output_path):
    top_companies.plot(kind='bar', title="Top Companies by Transactions", ylabel="Count")
    os.makedirs(output_path, exist_ok=True)
    plt.savefig(os.path.join(output_path, "top_companies.png"))
    plt.close()
def plot_category_distribution(data, output_path):
    sns.countplot(data=data, x='category')
    plt.title("Message Category Distribution")
    plt.xlabel("Category")
    plt.ylabel("Count")
    os.makedirs(output_path, exist_ok=True)
    plt.savefig(os.path.join(output_path, "category_distribution.png"))
    plt.close()

def plot_message_trends(data, output_path):
    data['month'] = data['updateAt'].dt.to_period('M')
    trend_data = data[data['category'] == 'Financial'].groupby('month').size()
    trend_data.plot(kind='line', title="Monthly Financial Message Trends", ylabel="Count")
    os.makedirs(output_path, exist_ok=True)
    plt.savefig(os.path.join(output_path, "financial_trends.png"))
    plt.close()

def plot_financial_insights(financial_data, output_path):
    if financial_data.empty:
        return

    # Plot total amounts by sender
    sender_totals = financial_data.groupby('senderAddress')['amount'].sum()
    sender_totals.plot(kind='bar', title='Total Amount by Sender', ylabel='Amount (Rs)', xlabel='Sender')
    os.makedirs(output_path, exist_ok=True)
    plt.savefig(os.path.join(output_path, "financial_insights_by_sender.png"))
    plt.close()

    # Monthly financial trends
    monthly_totals = financial_data.groupby('month')['amount'].sum()
    monthly_totals.plot(kind='line', title='Monthly Financial Transaction Trends', ylabel='Total Amount (Rs)', xlabel='Month')
    plt.savefig(os.path.join(output_path, "financial_insights_trends.png"))
    plt.close()
